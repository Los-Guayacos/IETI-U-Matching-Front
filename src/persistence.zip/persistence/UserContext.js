import React from "react"

const UserContext = React.createContext({
    id: String
})

export default UserContext;